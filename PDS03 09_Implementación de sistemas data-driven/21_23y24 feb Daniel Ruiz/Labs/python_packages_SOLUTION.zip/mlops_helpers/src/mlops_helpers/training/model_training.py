from sklearn.ensemble import RandomForestClassifier
        
def train_random_forest(X_train, y_train, max_depth, n_estimators, random_state):
    # Train the model
    clf = RandomForestClassifier(max_depth=max_depth, n_estimators=n_estimators, random_state=random_state)
    clf.fit(X_train, y_train)
    
    return clf

