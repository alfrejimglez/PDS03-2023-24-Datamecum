from sklearn.datasets import load_iris

def ingest_data():
    
    # Load the iris dataset
    iris = load_iris()

    #pylint: disable=no-member
    X = iris.data
    y = iris.target
    
    return X, y